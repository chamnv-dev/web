# -*- coding: utf-8 -*-
APP_NAME = "Video Super Ultra"
APP_VERSION = "1.0.0.0"
def get_version():
    return APP_VERSION
def get_app_name():
    return APP_NAME
def get_app_title():
    return f"{APP_NAME} — Version: {APP_VERSION}"
