LABS_BASE='https://aisandbox-pa.googleapis.com'
UPLOAD_IMAGE_URL=f"{LABS_BASE}/v1:uploadUserImage"
T2V_URL=f"{LABS_BASE}/v1/video:batchAsyncGenerateVideoText"
I2V_URL=f"{LABS_BASE}/v1/video:batchAsyncGenerateVideoStartImage"
BATCH_CHECK_URL=f"{LABS_BASE}/v1/video:batchCheckAsyncVideoGenerationStatus"
