# Báo cáo dọn dẹp dự án (low-risk)
- Thời điểm: 2025-10-30 02:01:18

## Entry points phát hiện
- main_image2video
- ui

## Đã xóa (module .py không được dùng)
- tests/smoke.py

## Đã xóa (tài nguyên không tham chiếu)
- branding.json
- constraints.txt
- VERSION
- tests

## Đã xóa (artefact/dev-only)
- tests/smoke.py
- branding.json
- constraints.txt
- VERSION
- tests

## Thư mục quét động phát hiện (giữ an toàn)
