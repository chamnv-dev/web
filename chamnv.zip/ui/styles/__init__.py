# -*- coding: utf-8 -*-
"""UI styles package"""
