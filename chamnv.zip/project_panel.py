# -*- coding: utf-8 -*-
from ui.project_panel import ProjectPanel  # shim
